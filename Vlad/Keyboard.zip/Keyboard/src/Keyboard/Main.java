package Keyboard;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
		Task.LoadDictionary("Dictionary.json");

        Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
        primaryStage.setTitle("Клавиатурный тренажер");
        primaryStage.setScene(new Scene(root, 1150, 500));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
