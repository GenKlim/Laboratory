﻿The SharpGLCore package has been renamed to SharpGL.

The new package has been automatically installed. You can now safely
remove the SharpGLCore package.