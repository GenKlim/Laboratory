Z=[-1+2i,-2-3i,2+3i,5+2i]; 
compass(Z)