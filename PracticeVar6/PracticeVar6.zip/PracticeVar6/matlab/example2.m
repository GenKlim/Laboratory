x=0:0.1*pi:3*pi; 
y=0.05+i; 
z=exp(x*y); 
feather(z)